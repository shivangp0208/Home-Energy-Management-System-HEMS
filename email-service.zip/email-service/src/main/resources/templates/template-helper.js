/**
 * Email Template Helper for VPP Verification Notifications
 * Use this to generate the HTML email content with dynamic data
 */

/**
 * Generate VPP Verification Email HTML
 * Sends to VPP Operator after they upload verification documents
 * @param {Object} data - Email data object
 * @returns {string} HTML email content
 */
function generateVppVerificationEmail(data) {
  const {
    vppOperatorName = 'VPP Operator',
    vppName = 'VPP Site',
    location = 'Location TBD',
    uploadDate = new Date().toLocaleString(),
    documents = [],
    dashboardUrl = 'https://enerrest.com/dashboard'
  } = data;

  // Build documents HTML
  let documentsHtml = '';
  if (Array.isArray(documents) && documents.length > 0) {
    documentsHtml = documents.map(doc => `
      <div class="document-item">
        <div class="document-icon">📄</div>
        <div class="document-info">
          <div class="document-name">${doc.fileName || 'Document'}</div>
          <div class="document-meta">${doc.fileSize || 'N/A'} • ${doc.uploadDate || 'Today'}</div>
        </div>
        <div class="document-status">Pending</div>
      </div>
    `).join('');
  }

  const emailHtml = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VPP Verification Documents Uploaded - EnerNest</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            line-height: 1.6;
            color: #0f172a;
            background-color: #f8fafc;
        }

        .email-container {
            max-width: 600px;
            margin: 0 auto;
            background-color: #ffffff;
        }

        .header {
            background: linear-gradient(135deg, #22c55e 0%, #16a34a 100%);
            padding: 30px 20px;
            text-align: center;
            border-bottom: 4px solid #0ea5e9;
        }

        .header-content {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
        }

        .logo {
            width: 40px;
            height: 40px;
            background-color: rgba(255, 255, 255, 0.3);
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .header h1 {
            color: #ffffff;
            font-size: 24px;
            font-weight: 700;
        }

        .main-content {
            padding: 40px 30px;
        }

        .greeting {
            margin-bottom: 25px;
        }

        .greeting h2 {
            color: #0f172a;
            font-size: 20px;
            font-weight: 600;
            margin-bottom: 8px;
        }

        .greeting p {
            color: #64748b;
            font-size: 14px;
        }

        .alert-box {
            background-color: #fef3c7;
            border-left: 4px solid #facc15;
            padding: 15px;
            margin: 25px 0;
            border-radius: 6px;
        }

        .alert-box p {
            color: #854d0e;
            font-size: 13px;
            margin: 0;
        }

        .details-section {
            background-color: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 25px;
            margin: 30px 0;
        }

        .section-title {
            color: #0f172a;
            font-size: 16px;
            font-weight: 600;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .section-title::before {
            content: '';
            width: 4px;
            height: 16px;
            background-color: #22c55e;
            border-radius: 2px;
        }

        .detail-row {
            display: flex;
            justify-content: space-between;
            padding: 12px 0;
            border-bottom: 1px solid #e2e8f0;
        }

        .detail-row:last-child {
            border-bottom: none;
        }

        .detail-label {
            color: #64748b;
            font-size: 13px;
            font-weight: 500;
        }

        .detail-value {
            color: #0f172a;
            font-size: 13px;
            font-weight: 600;
        }

        .documents-section {
            background-color: #f0fdf4;
            border: 1px solid #bbf7d0;
            border-radius: 8px;
            padding: 20px;
            margin: 25px 0;
        }

        .document-item {
            background-color: #ffffff;
            border: 1px solid #dcfce7;
            border-radius: 6px;
            padding: 15px;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .document-item:last-child {
            margin-bottom: 0;
        }

        .document-icon {
            width: 40px;
            height: 40px;
            background-color: #dcfce7;
            border-radius: 6px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
        }

        .document-info {
            flex: 1;
        }

        .document-name {
            color: #0f172a;
            font-size: 13px;
            font-weight: 600;
            margin-bottom: 4px;
        }

        .document-meta {
            color: #64748b;
            font-size: 12px;
        }

        .document-status {
            background-color: #dbeafe;
            color: #0284c7;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
        }

        .action-section {
            text-align: center;
            margin: 35px 0;
        }

        .action-button {
            display: inline-block;
            background: linear-gradient(135deg, #22c55e 0%, #16a34a 100%);
            color: #ffffff;
            padding: 14px 35px;
            text-decoration: none;
            border-radius: 8px;
            font-weight: 600;
            font-size: 14px;
        }

        .info-box {
            background-color: #eff6ff;
            border: 1px solid #bfdbfe;
            border-radius: 8px;
            padding: 20px;
            margin: 25px 0;
        }

        .info-box h3 {
            color: #0c4a6e;
            font-size: 14px;
            font-weight: 600;
            margin-bottom: 8px;
        }

        .info-box ul {
            margin-left: 20px;
            color: #0c4a6e;
            font-size: 13px;
        }

        .info-box li {
            margin-bottom: 6px;
        }

        .footer {
            background-color: #1e293b;
            color: #f1f5f9;
            padding: 30px 20px;
            text-align: center;
            border-top: 1px solid #334155;
        }

        .footer-content {
            max-width: 600px;
            margin: 0 auto;
        }

        .footer-logo {
            margin-bottom: 15px;
            font-size: 16px;
            font-weight: 600;
        }

        .footer-text {
            font-size: 12px;
            color: #94a3b8;
            margin-bottom: 10px;
        }

        .footer-links {
            font-size: 12px;
            margin: 15px 0;
        }

        .footer-links a {
            color: #22c55e;
            text-decoration: none;
            margin: 0 10px;
        }

        .divider {
            height: 1px;
            background-color: #334155;
            margin: 15px 0;
        }

        @media (max-width: 600px) {
            .main-content {
                padding: 20px 15px;
            }

            .details-section,
            .documents-section {
                padding: 15px;
            }

            .detail-row {
                flex-direction: column;
                gap: 5px;
            }

            .header h1 {
                font-size: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="email-container">
        <div class="header">
            <div class="header-content">
                <div class="logo">⚡</div>
                <h1>EnerNest</h1>
            </div>
        </div>

        <div class="main-content">
            <div class="greeting">
                <h2>Documents Uploaded Successfully</h2>
                <p>Hello ${vppOperatorName},</p>
            </div>

            <div class="alert-box">
                <p>✅ Your verification documents have been successfully uploaded and are now pending review.</p>
            </div>

            <div class="details-section">
                <div class="section-title">Your VPP Site Information</div>
                <div class="detail-row">
                    <span class="detail-label">VPP Name:</span>
                    <span class="detail-value">${vppName}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Location:</span>
                    <span class="detail-value">${location}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Upload Date:</span>
                    <span class="detail-value">${uploadDate}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Verification Status:</span>
                    <span class="detail-value" style="color: #0284c7;">⏳ Pending Review</span>
                </div>
            </div>

            <div class="documents-section">
                <div class="section-title">Your Uploaded Documents</div>
                ${documentsHtml}
            </div>

            <div class="info-box">
                <h3>What Happens Next:</h3>
                <ul>
                    <li>Your documents will be reviewed by our VPP Management team</li>
                    <li>You'll receive a notification when the verification is complete</li>
                    <li>If additional information is needed, we'll contact you directly</li>
                    <li>Once approved, your site will be active and begin reporting energy data</li>
                </ul>
            </div>

            <div class="action-section">
                <a href="${dashboardUrl}" class="action-button">View Your VPP Dashboard</a>
            </div>

            <div style="background-color: #f8fafc; border-left: 4px solid #0ea5e9; padding: 15px; margin: 25px 0; border-radius: 6px;">
                <p style="color: #0c4a6e; font-size: 13px; margin: 0;">
                    <strong>Estimated Review Time:</strong> Your documents will typically be reviewed within 24-48 hours. You can check the status of your verification anytime in your dashboard.
                </p>
            </div>
        </div>

        <div class="footer">
            <div class="footer-content">
                <div class="footer-logo">⚡ EnerNest - Virtual Power Plant Management</div>
                <div class="footer-text">Smart energy management for distributed power systems</div>
                <div class="divider"></div>
                <div class="footer-text">This is an automated notification from EnerNest. Please do not reply to this email.</div>
                <div class="footer-links">
                    <a href="#">Dashboard</a>
                    <a href="#">Help Center</a>
                    <a href="#">Settings</a>
                </div>
                <div class="footer-text" style="margin-top: 15px; color: #64748b; font-size: 11px;">
                    © 2026 EnerNest. All rights reserved.
                </div>
            </div>
        </div>
    </div>
</body>
</html>`;

  return emailHtml;
}

// Example usage for backend (send to VPP Operator):
// const emailContent = generateVppVerificationEmail({
//   vppOperatorName: 'John Smith',
//   vppName: 'torent-power-house-1',
//   location: '123 Power Street, City, State',
//   uploadDate: new Date().toLocaleString(),
//   documents: [
//     { fileName: 'License-Certificate.pdf', fileSize: '2.4 MB', uploadDate: 'Feb 9, 2026' },
//     { fileName: 'Site-Photos.zip', fileSize: '15.8 MB', uploadDate: 'Feb 9, 2026' },
//     { fileName: 'Technical-Specs.pdf', fileSize: '1.2 MB', uploadDate: 'Feb 9, 2026' }
//   ],
//   dashboardUrl: 'https://enerrest.com/dashboard'
// });

// Send via nodemailer or your preferred email service
// const transporter = nodemailer.createTransport({...});
// await transporter.sendMail({
//   to: 'operator@enerrest.com',  // VPP Operator's email
//   subject: 'Documents Uploaded Successfully - Pending Review',
//   html: emailContent
// });

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { generateVppVerificationEmail };
}
